-- =============================================================================
-- MERCADO SUMAJ — DENUNCIAS DE PUBLICACIONES
-- Copia y pega TODO este archivo en Supabase > SQL Editor > New query > Run.
-- Se puede ejecutar una sola vez (es seguro volver a correrlo si hace falta).
-- =============================================================================

create table if not exists public.reports (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid not null references public.products(id) on delete cascade,
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reason text not null,
  details text,
  status text not null default 'pending' check (status in ('pending','reviewed_valid','reviewed_dismissed')),
  admin_note text,
  created_at timestamptz not null default now()
);

alter table public.reports enable row level security;

drop policy if exists "reports_select" on public.reports;
create policy "reports_select" on public.reports for select using (
  reporter_id = auth.uid() or public.is_admin()
);

drop policy if exists "reports_insert" on public.reports;
create policy "reports_insert" on public.reports for insert with check (
  reporter_id = auth.uid()
);

drop policy if exists "reports_update" on public.reports;
create policy "reports_update" on public.reports for update using (
  public.is_admin()
);

-- =============================================================================
-- LISTO. Ya puedes usar el botón "Denunciar publicación" y revisar las
-- denuncias desde el panel de administrador, pestaña "Denuncias".
-- =============================================================================
